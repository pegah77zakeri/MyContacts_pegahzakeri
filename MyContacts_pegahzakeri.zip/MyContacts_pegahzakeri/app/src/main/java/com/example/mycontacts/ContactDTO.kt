package com.example.mycontacts

import android.graphics.Bitmap

class ContactDTO {
    var name = ""
    var number = ""
    var image: Bitmap? = null
}